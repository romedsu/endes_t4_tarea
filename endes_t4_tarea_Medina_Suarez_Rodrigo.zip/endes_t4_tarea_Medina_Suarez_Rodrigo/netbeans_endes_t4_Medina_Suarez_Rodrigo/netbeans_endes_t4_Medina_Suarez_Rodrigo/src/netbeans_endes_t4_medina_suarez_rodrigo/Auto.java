import java.util.ArrayList;

/**
 * Clase que representa un Auto<br>
 * La clase Auto representa una entidad sobre un coche<br>
 * con sus atributos de marca y modelo.<br>
 * @author Rodrigo Medina / Tunivers
 * @version 1.0, 20/02/2024
 */
public class Auto {

    /**
     * Marca del Auto<br>
     * La marca de fabricación del coche<br>
     */
    private String marca;

    /**
     * Modelo del Auto<br>
     * El modelo específico de fabricación del coche<br>
     */
    private String modelo;

    /**
     * Constructor de objetos de la clase Auto<br>
     * El constructor contiene los atributos necesario (marca,modelo)<br>
     * @param marca Marca del Auto
     * @param modelo Modelo del Auto
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Método getter para Marca<br>
     * Método que devuelve un String con la marca del coche<br>
     * @return String con la marca del Auto
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Asignar valor a Marca<br>
     * Establece el valor de la marca del coche<br>
     * @param marca La marca del Auto
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Método getter para Modelo<br>
     * Método que devuelve un String con el modelo del coche<br>
     * @return String con el modelo del Auto
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Asignar valor del Modelo<br>
     * Establece el valor del modelo del coche<br>
     * @param modelo El modelo del Auto
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Método que convierte la instancia del objeto en un String<br>
     * Método que devuelve un String con toda la info del Auto (marca, modelo)<br>
     * @return Un String sobre la marca y el modelo del Auto
     */
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}


