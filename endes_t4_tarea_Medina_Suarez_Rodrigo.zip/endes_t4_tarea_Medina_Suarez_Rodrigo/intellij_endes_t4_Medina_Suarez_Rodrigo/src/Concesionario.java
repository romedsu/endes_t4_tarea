import java.util.ArrayList;

/**
 * Clase que representa un Concesionario<br>
 * La clase Concesionario gestiona el inventario de un concesionario<br>
 *  para la agregar y modificar y listar nuevos Autos.<br>
 * @author Rodrigo Medina / Tunivers
 * @version 1.0, 20/02/2024
 */
public class Concesionario {

    /**
     * Lista de arrays de Auto<br>
     * Objeto de tipo ArrayList que contendrá objetos de tipo Auto<br>
     * que permite modificar y almacenar datos sobre Autos
     */
    private ArrayList<Auto> autos;

    /**
     * Constructor que inicializa una lista de Autos<br>
     * que inicializa una lista de Autos como una colección de ArrayList vacía<br>
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

    /**
     * Método que agregar un Auto<br>
     * Metodo requiere un objetos de tipo Auto que se añadirá a la lista Autos<br>
     * @param auto Auto a añadir
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * Método para listar Autos<br>
     * Permite listar Autos<br>
     * @return autos
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Método para imprimir Autos<br>
     * Método void que realiza una impresión de los Autos<br>
     */
    public void imprimirAutos(){
        for (Auto auto: autos){
            System.out.println(auto);
        }
    }
}

